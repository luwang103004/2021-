function [phrase_input,img_output] = GS_steps(img_initial,U_0,k,z,pixel,screen_range,XX,YY)
img_input=ifftshift(img_initial);
img_input_2=iRSD(k,z,pixel,screen_range,XX,YY,img_input);
phrase_input=angle(img_input_2);
img1=U_0.*exp(1i*phrase_input);
%img_output=img1;
img_output=fftshift(RSD(k,z,pixel,screen_range,XX,YY,img1));
end