%computer synthetic hologram
clc;
%clear;
close all;

bar=waitbar(0,'Calculating...','Name','Progress');
%img=imread('star1.bmp');
%img=rgb2gray(img);

img_original=ustc;
Y=768;
X=768;
z=400;
radius=100;
pixel=1;
screen_range=768/pixel;
wavelength=0.6328;
k=2*pi/wavelength;

dx=2;
dy=2;
x=((1:X)-(X-1)/2)*dx;
y=((1:Y)-(Y-1)/2)*dy;
[xx,yy]=meshgrid(x,y);
r=sqrt(xx.^2+yy.^2);

X(1:screen_range)=x(1)-x(screen_range:-1:1);
X(screen_range+1:2*screen_range)=x(1:screen_range)-x(1);
Y(1:screen_range)=y(1)-y(screen_range:-1:1);
Y(screen_range+1:2*screen_range)=y(1:screen_range)-y(1);
[XX,YY]=meshgrid(X,Y);

obj=zeros(size(r));
obj(r<=radius)=1;

omega_0=100;
U_0=exp(-(r/omega_0).^2);

rand_matrix=exp(2i*pi*rand(768,768));
img_initial=img_original.*rand_matrix;

[phrase_input,img_output]=GS_steps(img_initial,U_0,k,z,pixel,screen_range,XX,YY);
img_abs=abs(img_output);
Z=max(img_abs);
ZZ=max(Z);
img_figure=img_abs/ZZ;

temp=corrcoef(img_figure,img_original);
value_sim=img_sim(img_figure,img_original);
str=['Calculating...',num2str(value_sim,'%.4f')];
waitbar(value_sim,bar,str);

i=0;
while value_sim<0.138
    phrase_output=angle(img_output);
    img_initial=img_original.*exp(1i*phrase_output);
    [phrase_input,img_output]=GS_steps(img_initial,U_0,k,z,pixel,screen_range,XX,YY);
    img_abs=abs(img_output);
    Z=max(img_abs);
    ZZ=max(Z);
    img_figure=img_abs/ZZ;
    value_sim=img_sim(img_figure,img_original);
    i=i+1;
    str=['Calculating...',num2str(value_sim,'%.4f')];
    waitbar(value_sim,bar,str);
end


subplot(2,2,1);imshow(real(img_original));title('Original Image');
subplot(2,2,2);imshow(U_0);title('Light Distribution');
subplot(2,2,3);imshow(phrase_input);title('Phrase');
subplot(2,2,4);imshow(img_figure);title('Result Image');