function value = img_sim(img1,img2)
value_matrix=corrcoef(img1,img2);
value=min(value_matrix(:));
end