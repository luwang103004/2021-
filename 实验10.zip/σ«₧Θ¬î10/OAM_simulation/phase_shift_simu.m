clc;
close all;
tic;
%% Laguerre Gauss Beam
N=300; %pixel range           
lambda=633*1e-9;    
k=2*pi/lambda; 

w0=3e-3; %waist=3mm
Z_R=pi*w0^2/lambda; %Rayleigh length
z=0;          
w_z=w0*sqrt(1+(z/Z_R)^2);
row=linspace(-3*w0,3*w0,N);   
col=row;
[x,y]=meshgrid(row,col);
[theta,r]=cart2pol(x,y);

%p and l are orders of the Hermite poly
p=0;      
l=1;
E_01=Hermite(p,sqrt(2)*x/w_z).*Hermite(l,sqrt(2)*x/w_z).*exp(-1i*(p+l+1)*atan(z/Z_R)).*exp(1i*k*r.^2/2/(z-1i*Z_R));
I_01=E_01.*conj(E_01);      


p=1;
l=0;
E_10=Hermite(p,sqrt(2)*y/w_z).*Hermite(l,sqrt(2)*y/w_z).*exp(-1i*(p+l+1)*atan(z/Z_R)).*exp(1i*k*r.^2/2/(z-1i*Z_R));
I_10=E_10.*conj(E_10);
E=E_01+1i*E_10;

E_phase=angle(E);

%% four steps phase shift
a=1;
b=1;
alpha=30;
I_0=a+b*cos(alpha);
I_1=a+b*cos(alpha+E_phase+pi/4);
I_2=a+b*cos(alpha+E_phase+pi/2);
I_3=a+b*cos(alpha+E_phase+3*pi/4);
I_4=a+b*cos(alpha+E_phase+pi);

%need high frequency filter%
beta=atan((I_4.*I_4-I_2.*I_2)/(I_1.*I_1-I_3.*I_3));

toc;