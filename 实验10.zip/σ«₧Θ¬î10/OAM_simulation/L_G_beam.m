clc;
close all;
tic;
%% Laguerre Gauss Beam
N=300; %number of sample points           
lambda=633*1e-9;    
k=2*pi/lambda; 

w0=3e-3; %waist=3mm
z=0;          
w_z=w0*sqrt(1+(z/Z_R)^2);
Z_R=pi*w0^2/lambda; %Rayleigh length
row=linspace(-3*w0,3*w0,N);   
col=row;
[x,y]=meshgrid(row,col);
[theta,r]=cart2pol(x,y);

%p and l are orders of the Hermite poly
p=0;      
l=1;
E_01=Hermite(p,sqrt(2)*x/w_z).*Hermite(l,sqrt(2)*x/w_z).*exp(-1i*(p+l+1)*atan(z/Z_R)).*exp(1i*k*r.^2/2/(z-1i*Z_R));
I_01=E_01.*conj(E_01);      


p=1;
l=0;
E_10=Hermite(p,sqrt(2)*y/w_z).*Hermite(l,sqrt(2)*y/w_z).*exp(-1i*(p+l+1)*atan(z/Z_R)).*exp(1i*k*r.^2/2/(z-1i*Z_R));
I_10=E_10.*conj(E_10);

E=E_01+1i*E_10;
I=E.*conj(E);     
subplot(1,2,1)
h = pcolor(x,y,I);
set(h,'edgecolor','none','facecolor','interp');
title('LG_0_1 Light Distribution');
axis square;

subplot(1,2,2)
E_phase = angle(E);
h_phase = pcolor(x,y,E_phase);
set(h_phase,'edgecolor','none','facecolor','interp');
title('LG_0_1 Phase');
axis square;

toc;
