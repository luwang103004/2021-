function result = Hermite(n,x)
if n <= 0
    result = 1;
elseif n == 1
    result = 2*x;
else
    result = 2*x*Hermite(n-1,x)-2*(n-1)*Hermite(n-2,x);
end
end